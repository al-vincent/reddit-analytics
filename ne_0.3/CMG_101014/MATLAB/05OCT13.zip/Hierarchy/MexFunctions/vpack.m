% function U = vpack(V)
%
% Input:  V vector of boolean values ;
% Output: U(i)=j if V(i) is the j-th true value in V, 0 otherwise
%

error ('vpack mexFunction not found') ;
