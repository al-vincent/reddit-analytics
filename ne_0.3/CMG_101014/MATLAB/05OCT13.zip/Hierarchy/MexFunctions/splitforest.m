% function C1 = adjacency(C);
%
% input: 0-1 matrix with at most one non-zero per column
%
% output:  0-1 matrix with at most one non-zero per column
%          with fewer and smaller connected components

error ('splitforest mexFunction not found') ;
