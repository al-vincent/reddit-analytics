import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;


public class LinkWritable implements Writable{
	private Text link = new Text();
	private IntWritable count = new IntWritable();

	@Override
	public void readFields(DataInput in) throws IOException {
		this.link.readFields(in);
		this.count.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		this.link.write(out);
		this.count.write(out);
	}

	public void setLink(String str) {
		// Set the value of the sum field
		this.link.set(str);
	}
	
	public void setCount(int c) {
		// Set the value of the count field
		this.count.set(c);
	}
	
	public String getLink() {
		// Return the current value of 'link' as a String
		return this.link.toString();
	}
	
	public int getCount() {
		// Return the current value of 'count' as an int
		return this.count.get();
	}
	
	public String toString() {
		return this.link + "\t" + this.count;
	}
}
