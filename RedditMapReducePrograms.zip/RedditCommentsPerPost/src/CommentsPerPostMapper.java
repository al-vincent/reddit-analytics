/**=============================================================================
 * MSc Project - Reddit CommentsPerPost MapReduce Program (Mapper)
 * ---------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment data,  extracts the post ID, and emits 
 * 				<subreddit, (postID, 1)>
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/submissions/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CommentsPerPostMapper extends Mapper<Object, Text, Text, LinkWritable> {

	// Instance variables
	private Text subreddit = new Text();						
	private LinkWritable linkCount = new LinkWritable(); 

	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		
		// try to parse json
		String jsonString = value.toString();
		HashMap<String,String> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, String>>() {}.getType());
		
		// set instance variables from json input
		subreddit.set(comment.get("subreddit"));	// name of subreddit
		linkCount.setLink(comment.get("link_id"));	// unique ID of original link 
		linkCount.setCount(1);						// we see one instance per line of json
		
		// write output
		context.write(this.subreddit, this.linkCount);											   		
	}
}
