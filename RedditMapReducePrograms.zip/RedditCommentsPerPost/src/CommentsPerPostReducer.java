/**=============================================================================
 * MSc Project - Reddit CommentsPerPost MapReduce Program (Reducer)
 * ----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment data,  extracts the post ID, and emits 
 * 				<subreddit, (postID, 1)>
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/submissions/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CommentsPerPostReducer extends Reducer<Text, LinkWritable, Text, LinkWritable> {

	// Instance variables 
	private LinkWritable linkCount = new LinkWritable();	
	
	// The reducer method
	public void reduce(Text key, Iterable<LinkWritable> values, Context context)
			throws IOException, InterruptedException {
		
		// Create a hashmap to hold post ids and numbers of comments
		HashMap<String, Integer> linkIdCountMap = new HashMap<String, Integer>();
		// iterate through each (postID, count) pair, and increment number comment count
		for (LinkWritable val : values) {			
			// if postID isn't in the map, add it
			if(!linkIdCountMap.containsKey(val.getLink())){
				linkIdCountMap.put(val.getLink(), val.getCount());
			} else { //otherwise, increment
				linkIdCountMap.put(val.getLink(), linkIdCountMap.get(val.getLink()) + val.getCount());
			}			
		}
		
		// emit <subreddit, (postId, count)> 
		for(String link_id : linkIdCountMap.keySet()){
			linkCount.setLink(link_id);
			linkCount.setCount(linkIdCountMap.get(link_id));
			context.write(key, this.linkCount);
		}		
	}
}