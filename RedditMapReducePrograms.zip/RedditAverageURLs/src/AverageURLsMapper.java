/**=============================================================================
 * MSc Project - Reddit AverageURLs MapReduce Program (Mapper)
 * -----------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment data and extracts the number of 
 * 				URLs that occur in each comment. 
 * 
 * 				Emits <subredditName, (urlCount, 1)>
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/submissions/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AverageURLsMapper extends Mapper<Object, Text, Text, CountAverageWritable> {
	
	// Regex pattern for recognising a URL, based on RFC 3986
	private static final Pattern urlPattern = Pattern.compile("(?:^|[\\W])((ht|f)tp(s?):\\/\\/|www\\.)"
                + "(([\\w\\-]+\\.){1,}?([\\w\\-.~]+\\/?)*"
                + "[\\p{Alnum}.,%_=?&#\\-+()\\[\\]\\*$~@!:/{};']*)", 
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
	
	// instance of a SumCountWritable (custom output format)
	private CountAverageWritable countAverage = new CountAverageWritable();					
	
	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {		
		// The FileInputFormat will supply input elements to the mapper
		// line-by-line using the line number as a key.
		
		// Parse the reddit json input, by placing each key:value pair into a HashMap
		String jsonString = value.toString();
		HashMap<String,String> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, String>>() {}.getType());			
		
		// get the name of the subreddit
		Text subreddit = new Text(comment.get("subreddit"));
		
		// Calculate the Flesch-Kincaid grade level for the body text
		int numURLs = countURLs(comment.get("body"));
		
		// set the values for output
		countAverage.setAverage(numURLs);
		countAverage.setCount(1.0);
			 
		// Emit <key, value> pair - key = subreddit name, val = (numUrls, 1) 
		context.write(subreddit, countAverage);											   		
	}
	
	/**
	 * Count the number of URLs in an input string, using a regex pattern.
	 * Regex and method based on:
	 * https://stackoverflow.com/questions/5713558/detect-and-extract-url-from-a-string 
	 * 
	 * @param text the text whose sentences we wish to extract
	 * @return an integer representing the number of sentences in the text
	 */
	public static int countURLs(String input){
		Matcher matcher = urlPattern.matcher(input);
	
		// counter variable
		int urlCount = 0;

		// use the matcher to iterate through the input string
		while (matcher.find()) {
			// increment the counter each time the pattern is found.
			urlCount++;				   
		} 
		return urlCount;
	}
}