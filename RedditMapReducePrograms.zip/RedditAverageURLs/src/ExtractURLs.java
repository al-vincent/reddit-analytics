
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractURLs {
	
	// Pattern for recognising a URL, based off RFC 3986
	private static final Pattern urlPattern = Pattern.compile("(?:^|[\\W])((ht|f)tp(s?):\\/\\/|www\\.)"
                + "(([\\w\\-]+\\.){1,}?([\\w\\-.~]+\\/?)*"
                + "[\\p{Alnum}.,%_=?&#\\-+()\\[\\]\\*$~@!:/{};']*)", 
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
	
	public static int countURLs(String input){
		Matcher matcher = urlPattern.matcher(input);
	
		// counter variable
		int urlCount = 0;

		// use the matcher to iterate through the input string
		while (matcher.find()) {
			// increment the counter each time the pattern is found.
			urlCount++;				   
		} 
		return urlCount;
	}
	
	public static void main(String[] args) {
		// Test string, containing URLs (8 of them here)
		String str = "Stats for **[rebuyray](http://www.reddit.com/r/Loans/search?q=author%3A%27rebuyray%27&amp;restrict_sr=on)** on r/Loans\n\n\n---------------------------------------\n\n\n**Requester Stats**\n\n\n* [2 Loan(s) Requested](/req_) ([view all posts in r/loans by this user](http://www.reddit.com/r/Loans/search?syntax=cloudsearch&amp;q=author%3A%27rebuyray%27&amp;restrict_sr=on&amp;sort=new))\n* [0 Loan(s) Paid Back By This Redditor](/paid_) ([view](http://www.reddit.com/r/Loans/search?q=title%3Arebuyray+%5BPAID%5D&amp;restrict_sr=on&amp;sort=new))\n* [0 Loan(s) NOT Paid Back By This Redditor](/unpaid_) ([view](http://www.reddit.com/r/Loans/search?q=title%3Arebuyray+%5BUNPAID%5D&amp;restrict_sr=on&amp;sort=new))\n\n\n**Lender Stats**\n\n\n* [0 Loan(s) Granted To Others](/offer_)\n* [0 Loan(s) Paid Back To This Redditor](/paid_)\n* [0 Loan(s) NOT Paid Back To This Redditor](/unpaid_)\n\n\n---------------------------------------\n\n\n[member for: 2 years 9 months - total karma: 260](/meta_)\n\n\n---------------------------------------\n\n\n[report link](http://www.reddit.com/message/compose?to=%2Fr%2FLoans&amp;subject=cRedditBot%20Link%20Reported%20-%20redd.it/1u4ir0) or [send feedback](http://www.reddit.com/message/compose?to=interwhos&amp;subject=cRedditBot%20Feedback!)\n\n\n---------------------------------------\n\n\n[Want to start lending? Read this first!](http://www.reddit.com/r/Loans/comments/19y46n/meta_everything_i_can_think_of_to_give_a_first/)\n\n\n---------------------------------------\n\n\n[Hi! I'm the cRedditBot stats robot. Click here for more information about me.](http://www.reddit.com/r/Loans/comments/1j54kp/meta_credditbot_information/)\n\n\n---------------------------------------";
		int numUrls = countURLs(str);
		System.out.println("Number of URLs: " + numUrls);
	}
}
