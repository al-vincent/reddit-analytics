/**=============================================================================
 * MSc Project - Reddit PostType MapReduce Program (Mapper)
 * --------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit submission data from JSON file, line-by-line. 
 * 				
 * 				Extracts the name of the subreddit, and whether the post is a 
 * 				link post (i.e. links to an external URL) or a self post (i.e.
 * 				contains no URL and is a general 'thought' from the user). 
 * 				
 * 				For each line, outputs the name of the subreddit (key) and a
 * 				PostTypeWritable indicating whether the post was a link post or
 * 				a self post.  
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/submissions/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class PostTypeMapper extends Mapper<Object, Text, Text, PostTypeWritable> {

	// instance variables
	private Text subreddit = new Text();
	private PostTypeWritable postType = new PostTypeWritable();


	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {		

		// try to parse json
		String postJson = value.toString();
		// convert source json to HashMap for easy info retrieval
		HashMap<String, Object> post = new Gson().fromJson(postJson, new TypeToken<HashMap<String, Object>>() {}.getType());	
		
		// name of subreddit 		
		try {
			subreddit.set(post.get("subreddit").toString());
		} catch (NullPointerException e) {
			subreddit.set("<empty_name>");
		}
				
		// whether the post is a self-post		
		Boolean isSelfPost = null;	
		try {
			// will override the previous null if there's a boolean val in the json
			isSelfPost = Boolean.parseBoolean(post.get("is_self").toString());
		} catch (NullPointerException e) {
			// continue
		}
		
		// set the postType values. 
		if(isSelfPost == null) {
			// if it's a null post, setNullPostCount = 1 
			postType.setSelfPostCount(0);
			postType.setLinkPostCount(0);
			postType.setNullPostCount(1);
		} else if (isSelfPost){
			// if a self post then selfPostCount = 1
			postType.setSelfPostCount(1);
			postType.setLinkPostCount(0);
			postType.setNullPostCount(0);			
		} else {
			// otherwise, linkPostCount = 1.
			postType.setSelfPostCount(0);
			postType.setLinkPostCount(1);
			postType.setNullPostCount(0);		
		} 
		
		// write output
		context.write(this.subreddit, this.postType);										   		
	}
}
