/**=============================================================================
 * MSc Project - Reddit PostType MapReduce Program (Reducer)
 * ---------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Aggregates the self-post and link-post counts for each subreddit
 * 				and calculates the overall proportion of self-posts and link-
 * 				posts (per subreddit).
 * 
 *   			Emits the subreddit, self-post count, link-post count, 
 *   			self-post %, and link-post % 
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/submissions/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class PostTypeReducer extends Reducer<Text, PostTypeWritable, Text, PostTypeWritable> {

	// Instance variable
	private PostTypeWritable result = new PostTypeWritable();
	
	// The reducer method
	public void reduce(Text key, Iterable<PostTypeWritable> values, Context context) throws IOException, InterruptedException {		
		int selfPostCount = 0;
		int linkPostCount = 0;
		int nullPostCount = 0;
		
		// Iterate through each value, and increment selfPostCount, linkPostCount and nullPostCount accordingly
		for (PostTypeWritable val : values) {
			selfPostCount += val.getSelfPostCount();
			linkPostCount += val.getLinkPostCount();
			nullPostCount += val.getNullPostCount();
		}
		
		// set result values
		result.setSelfPostCount(selfPostCount);
		result.setLinkPostCount(linkPostCount);
		result.setNullPostCount(nullPostCount);
		
		// Calculate the proportions of self posts and link posts
		// Note that even though this is not an associative operation, because the data is encapsulated 
		// and because the proportions are overwritten before ever being used / seen at the Combiner, we can 
		// use a simple reduce method (rather than the more complex method normally used for averaging values).
		double totalPosts = (double)(result.getLinkPostCount() + result.getSelfPostCount() + result.getNullPostCount());
		
		// set result values
		result.setSelfPostPercent(result.getSelfPostCount() / totalPosts);
		result.setLinkPostPercent(result.getLinkPostCount() / totalPosts);
		result.setNullPostPercent(result.getNullPostCount() / totalPosts);
		
		// Output the result
		context.write(key, result);
	}
}