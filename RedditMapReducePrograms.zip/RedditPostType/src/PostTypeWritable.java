import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;

public class PostTypeWritable implements Writable{	
	private IntWritable selfPostCount = new IntWritable();
	private IntWritable linkPostCount = new IntWritable();
	private IntWritable nullPostCount = new IntWritable();
	private DoubleWritable selfPostPercent = new DoubleWritable();
	private DoubleWritable linkPostPercent = new DoubleWritable();
	private DoubleWritable nullPostPercent = new DoubleWritable();

	@Override
	public void readFields(DataInput in) throws IOException {		
		this.selfPostCount.readFields(in);
		this.linkPostCount.readFields(in);
		this.nullPostCount.readFields(in);
		this.selfPostPercent.readFields(in);
		this.linkPostPercent.readFields(in);
		this.nullPostPercent.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		//this.postId.write(out);
		this.selfPostCount.write(out);
		this.linkPostCount.write(out);
		this.nullPostCount.write(out);
		this.selfPostPercent.write(out);
		this.linkPostPercent.write(out);
		this.nullPostPercent.write(out);
	}

	public void setSelfPostCount(int i) {
		// Set the value of the 'selfPostCount' field
		this.selfPostCount.set(i);
	}
	
	public void setLinkPostCount(int i) {
		// Set the value of the 'linkPostCount' field
		this.linkPostCount.set(i);
	}
	
	public void setNullPostCount(int i) {
		// Set the value of the 'linkPostCount' field
		this.nullPostCount.set(i);
	}
	
	public void setSelfPostPercent(double d) {
		// Set the value of the 'linkPostCount' field
		this.selfPostPercent.set(d);
	}
	
	public void setLinkPostPercent(double d) {
		// Set the value of the 'linkPostCount' field
		this.linkPostPercent.set(d);
	}
	
	public void setNullPostPercent(double d) {
		// Set the value of the 'linkPostCount' field
		this.nullPostPercent.set(d);
	}
	
	public int getSelfPostCount() {
		// Return the current value of 'selfPostCount' as an int
		return this.selfPostCount.get();
	}
	
	public int getLinkPostCount() {
		// Return the current value of 'linkPostCount' as an int
		return this.linkPostCount.get();
	}
	
	public int getNullPostCount() {
		// Return the current value of 'linkPostCount' as an int
		return this.nullPostCount.get();
	}
	
	public void getSelfPostPercent() {
		// Set the value of the 'linkPostCount' field
		this.selfPostPercent.get();
	}
	
	public void getLinkPostPercent() {
		// Set the value of the 'linkPostCount' field
		this.linkPostPercent.get();
	}
	
	public void getNullPostPercent() {
		// Set the value of the 'linkPostCount' field
		this.nullPostPercent.get();
	}
	
	public String toString() {
		return this.selfPostCount + "\t" + this.linkPostCount + "\t" + this.nullPostCount + "\t" +  
	this.selfPostPercent + "\t" + this.linkPostPercent + "\t" + this.nullPostPercent;
	}
}

