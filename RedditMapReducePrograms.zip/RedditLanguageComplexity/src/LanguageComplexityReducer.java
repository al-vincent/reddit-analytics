/** =============================================================================
 * MSc Project - Reddit LanguageComplexity MapReduce Program (Mapper)
 * ------------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment text and calculates the Flesch-Kincaid
 *				grade level score for each comment. To do this, gets:
 *				- number of sentences in body-text (via opennlp)
 *				- number of words in body-text (via opennlp)
 *				- number of syllables in body-text (estimate, using heuristic)
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class LanguageComplexityReducer extends Reducer<Text, CommentWritable, Text, CommentWritable> {

	// instance variables 
	private CommentWritable result = new CommentWritable();
	
	// The reducer method
	public void reduce(Text key, Iterable<CommentWritable> values, Context context)
			throws IOException, InterruptedException {
				
		double sum = 0.;
		double count = 0.;
		for (CommentWritable val : values) {
			// accumulate the result in the 'sum' variable
			sum += val.getCount() * val.getFleschKincaid();
			count += val.getCount();
		}
		
		// Set and out put the result
		result.setCount(count);
		result.setFleschKincaid(sum / count);		
		context.write(key, result);
	}
}