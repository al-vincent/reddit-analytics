import java.util.ArrayList;
import java.util.HashMap;

public class TestCalculateComplexity {
	public static void testSyllableCount(){
		HashMap<String, Integer> testMap = new HashMap<String, Integer>();
		
		testMap.put("unity", 3);
		testMap.put("Unite", 2);
		testMap.put("Growth", 1);
		testMap.put("possibilities", 5);
		testMap.put("MONOSYLLABIC", 5);
		testMap.put("Eucalyptus", 4);
		testMap.put("xylophone", 3);
		testMap.put("because", 2);
		testMap.put("baby", 2);
		testMap.put("therefore", 2);	// AV: I expect the method to get this one wrong!
		
		TextComplexity cc = new TextComplexity();
		for(String key : testMap.keySet()){
			System.out.println(key + ": expected " + testMap.get(key) + ", calculated " + cc.countSyllablesInWord(key));
		}		
	}
	
	public static void testSentenceCount(){
		
		HashMap<String, Integer> testMap = new HashMap<String, Integer>(); 
		String text = null;
		
		text = "Usually Sentence Detection is done before the text is tokenized and that's the way the pre-trained models on the web site are trained, but it is also possible to perform tokenization first and let the Sentence Detector process the already tokenized text. The OpenNLP Sentence Detector cannot identify sentence boundaries based on the contents of the sentence. A prominent example is the first sentence in an article where the title is mistakenly identified to be the first part of the first sentence. Most components in OpenNLP expect input which is segmented into sentences.";
		testMap.put(text, 4);
		
		text = "The easiest way to try out the Sentence Detector is the command line tool. The tool is only intended for demonstration and testing. Download the english sentence detector model and start the Sentence Detector Tool with this command.";
		testMap.put(text, 3);
		
		text = "Pierre Vinken, 61 years old, will join the board as a nonexecutive director Nov. 29. Mr. Vinken is chairman of Elsevier N.V., the Dutch publishing group. Rudolph Agnew, 55 years old and former chairman of Consolidated Gold Fields PLC, was named a director of this British industrial conglomerate.";
		testMap.put(text, 3);
		
		TextComplexity cc = new TextComplexity();
		for(String key : testMap.keySet()){
			System.out.println("Number of sentences: " + cc.countSentences(key) + ". Expected: " + testMap.get(key));
		}
	}
	
	public static void testWordCount(){
		HashMap<String, Integer> testMap = new HashMap<String, Integer>();
		String text = null;
		
		text = "I think, therefore I am";
		testMap.put(text, 5);
		
		text = "I am (because I think)";
		testMap.put(text, 5);
		
		text = "There is no full stop in this sentence";
		testMap.put(text, 8);
		
		TextComplexity cc = new TextComplexity();
		for(String key : testMap.keySet()){
			System.out.println("Number of words: " + cc.wordsInText(key) + ". Expected: " + testMap.get(key));
			
		}
	}
	
	public static void testSyllableCountInText(){
		HashMap<String, String> testMap = new HashMap<String, String>();
		String text = null;
		
		text = "I think, therefore I am";
		testMap.put(text, "6,5,1");
		
		text = "I am (because I think)";
		testMap.put(text, "6,5,1");
		
		text = "There is no full stop in this sentence";
		testMap.put(text, "9,8,1");
		
		TextComplexity cc = new TextComplexity();
		for(String key : testMap.keySet()){
			System.out.println("\"" + key + "\"");
			int sylCount = Integer.parseInt(testMap.get(key).substring(0,1));
			int wdCount = Integer.parseInt(testMap.get(key).substring(2,3));
			int sentenceCount = Integer.parseInt(testMap.get(key).substring(4,5));
			ArrayList<String> words = cc.wordsInText(key);
			System.out.println("Syllables: " + cc.countSyllablesInText(words) + ". Expected: " + sylCount);
			System.out.println("Words: " + words.size() + ". Expected: " + wdCount);
			System.out.println("Sentences: " + cc.countSentences(key) + ". Expected: " + sentenceCount);
			System.out.println();
		}
	}
	
	public static void testFleschKincaid(){
		TextComplexity cc = new TextComplexity();
		String text = "Roses are red. Violets are blue. Sugar is sweet, And so are you!";
		System.out.println("Flesch-Kincaid: " + cc.fleschKincaid(text) + ", Expected: 0.6230769230769244");
		
		text = "honestly, performing is one of the few social activities that gives me the least anxiety. i get more anxiety going to a dinner party or being at an airport. i think every anxiety disorder is different. mine is mostly based on small human interactions and conversation rather than being in front of a lot of people singing and dancing. it's kind of odd, to be honest. ";
		System.out.println("Flesch-Kincaid: " + cc.fleschKincaid(text));
	}
	
	public static void main(String[] args) {
		//testSyllableCount();
		//testSentenceCount();
		//testWordCount();
		//testSyllableCountInText();
		testFleschKincaid();
	}
}
