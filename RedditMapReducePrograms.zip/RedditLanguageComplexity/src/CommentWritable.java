import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;


public class CommentWritable implements Writable{
	private Text postId = new Text();
	private DoubleWritable fleschKincaid = new DoubleWritable();
	private DoubleWritable count = new DoubleWritable();

	@Override
	public void readFields(DataInput in) throws IOException {
		//this.postId.readFields(in);
		this.fleschKincaid.readFields(in);
		this.count.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		//this.postId.write(out);
		this.fleschKincaid.write(out);
		this.count.write(out);
	}

	public void setPostId(String str) {
		// Set the value of the 'postId' field
		this.postId.set(str);
	}
	
	public void setFleschKincaid(double fc) {
		// Set the value of the 'fleschKincaid' field
		this.fleschKincaid.set(fc);
	}
	
	public void setCount(double c) {
		// set the value of the 'count' field
		this.count.set(c);
	}
	
	public String getPostId() {
		// Return the current value of 'postId' as a String
		return this.postId.toString();
	}
	
	public double getFleschKincaid() {
		// Return the current value of 'fleschKincaid' as a double
		return this.fleschKincaid.get();
	}
	
	public double getCount() {
		// Return the current value of 'count' as a double
		return this.count.get();
	}
	
	public String toString() {
		return this.postId + "\t" + this.fleschKincaid + "\t" + this.count;
	}
}
