/**
 * Language Complexity Calculator
 * ------------------------------
 * 
 * @author: 	A. Vincent
 * 
 * Description: Uses the Flesch-Kincaid grade-level score algorithm to estimate the complexity
 * 				of the language used within a passage of (English) text. 
 * 				
 * Steps: 		
 * 				1. Check whether the text is (recognisably) in English.
 * 				2. If so:
 * 					a) Use OpenNLP to extract the number of sentences and words
 * 					b) Use a heuristic to estimate the number of syllables
 * 				3. Calculate Flesch-Kincaid, using:
 *  				Grade = C_0 + C_1 * (num_words / num_sentences) + C_2 * (num_syllables / num_words)
 * 
 * Notes: 		Almost all of the above can go at least slightly wrong. Most importantly:
 * 				1. The language-recognition aspect is trained on well-written text; may not 
 * 					perform so well when presented with poorly-written text.
 * 				2. OpenNLP and the heuristic may make mistakes ref number of sentences, words and syllables.
 * 				3. Flesch-Kincaid is limited; it makes *no* attempt to assess what the text actually says, 
 * 					whether spelling of words is correct etc.     
 *
 * TODO:
 * 1. Implement language recognition (see OpenNLP docs)
 * 2. Implement tokenisation / word-counting 
 * 		> N.B. This may not be trivial!! Will need to think about how to handle punctuation characters etc.
 * 		# DONE - but should really read from a dictionary first, than use heuristics if word not in dict?
 * 3. Consider altering syllable counter to use a dictionary initially, then heuristics if word not in dict
 * 5. Test (rigorously!) against example passages    				
 * */

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class TextComplexity {
	
	// set modelPath to the directory containing the OpenNLP model files (Project\lib) 
	private final String modelPath = System.getProperty("user.dir") + "\\lib\\";
	// strings to be used as 'vowels' (i.e. incl 'y')
	private final HashSet<String> vowels = new HashSet<String>(Arrays.asList("a", "e", "i", "o", "u", "y"));
	
	// Flesch-Kincaid constants (experimentally derived)
	private final double C_0 = -15.59;
	private final double C_1 = 0.39;
	private final double C_2 = 11.8;
	
	/**
	 * Heuristic method to approximate the number of syllables in a word (in English). 
	 * Calculated by counting the number of vowels (incl 'y') in a word, excluding cases where:
	 * 	- vowels that have vowels directly before them;
	 *  - the letter 'e' appears by itself at the end of a word.
	 *  
	 * @param word String, word that we want to estimate the number of syllables for.
	 * @return int representing the approximate number of syllables in 'word' 
	 */
	public int countSyllablesInWord(String word){
		// Vowels are all lower case, so set the word to be lower case too
		word = word.toLowerCase();
		// initialise syllable counter
		int sylCount = 0;
		// word length is used a few times, so store in a variable
		int wordLength = word.length();
		
		// look through each character in the word
		for(int i = 0; i < wordLength; i++){
			// if the character is a vowel, then...
			if(vowels.contains(word.substring(i, i+1))){
				//.. if it's the first letter, increment the syllable counter
				if(i == 0){
					sylCount++;
				// if it's not the first or last letter, and the previous letter
				// is not a vowel, then increment the syllable counter
				} else if(i > 0 && i < wordLength-1 && !vowels.contains(word.substring(i-1, i))){
					sylCount++;
				// finally, if it's the last letter, *not* an 'e' and the previous 
				// letter isn't a vowel, then increment the syllable counter
				} else if(i == wordLength-1 && word.charAt(i) != 'e' && !vowels.contains(word.substring(i-1, i))){
					sylCount++;
				}
			}
		}
		
		// A word can never have less than one syllable; if it does (e.g. an abbreviation),  
		// set the count to 1
		if(sylCount < 1) sylCount = 1;
		
		return sylCount;
	}
	
	/**
	 * Count the total number of syllables in a collection of words.
	 * 
	 * @param text an ArrayList<String>, where each entry is a single word 
	 * that we want to count the number of syllables for. 
	 * @return int representing the (approximate) total number of syllables 
	 * in all words in 'text'
	 */
	public int countSyllablesInText(ArrayList<String> text){
		
		// initialise the counter to zero
		int syllableCount = 0;
		// iterate through each word in the ArrayList
		for(String word : text){
			// update syllableCount with number of syllables in the word
			syllableCount += countSyllablesInWord(word);
		}
		return syllableCount;
	}
	
	/**
	 * Count the number of sentences in a piece of text. Uses OpenNLP's SentenceModel
	 * to provide a high level of accuracy on sentence estimation.
	 *   
	 * @param text the text whose sentences we wish to extract
	 * @return an integer representing the number of sentences in the text
	 */
	public int countSentences(String text) {
		
		// declare 'model' here to avoid putting everything in try/catch block 
		SentenceModel model = null;
			
		// 
		try (InputStream modelIn = new FileInputStream(modelPath + "en-sent.zip")) {
			  model = new SentenceModel(modelIn);
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		// Create SentenceDetector object from the model above
		SentenceDetectorME sentenceDetector = new SentenceDetectorME(model);

		// Detect the sentences in 'text'. Store each sentence as an element in an 
		// array of strings
		String sentences[] = sentenceDetector.sentDetect(text);
		
		// The number of elements in this array is the number of sentences 
		return sentences.length;				
	}
	
	/**
	 * Tokenise a passage of text and extract likely words from that text (removing
	 * punctuation, white space etc).
	 * 
	 * @param text a String to be tokenized
	 * @return words an ArrayList<String> of likely words
	 * 
	 * NOTES:
	 * 	- The method used to identify 'words' is not currently very accurate; just
	 * 	  looks for tokens that begin with a letter.
	 */
	public ArrayList<String> wordsInText(String text){
		
		// variable to hold the word-count
		ArrayList<String> words = new ArrayList<String>();
		
		// set up the TokenizerModel
		TokenizerModel model = null;		
		try (InputStream modelIn = new FileInputStream(modelPath + "en-token.zip")) {
			  model = new TokenizerModel(modelIn);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// Create a Tokenizer object 
		Tokenizer tokenizer = new TokenizerME(model);
		
		// Get the tokens from the input text and store in a String array
		String tokens[] = tokenizer.tokenize(text);
		
		// Look through each token - if the first char is a letter, then 
		// treat the token as a word and add to the arraylist
		for(String token : tokens){
			if(Character.isLetter(token.charAt(0))){
				words.add(token);
			}
		}
		
		return words;
	}
	
	/**
	 * Calculate the Flesch-Kincaid grade score for a piece of text. Briefly; Flesch-Kincaid 
	 * provides an approximation of the complexity of a piece of text. The higher the number,
	 * the more complex the language used in the text. For more details, see 
	 * https://en.wikipedia.org/wiki/Flesch%E2%80%93Kincaid_readability_tests
	 *    
	 * Formula is:
	 * 	Grade = C_0 + C_1 * (num_words / num_sentences) + C_2 * (num_syllables / num_words),
	 * where C_0, C_1, C_2 are constants.
	 * 
	 * @param text the text that we want to calculate Flesch-Kincaid for.
	 * @return a double representing the Flesch-Kincaid Grade Level 
	 */
	public double fleschKincaid(String text){
		int numSentences = countSentences(text);
		ArrayList<String> words = wordsInText(text);
		int numWords = words.size();
		int numSyllables = countSyllablesInText(words);
		
		return C_0 + C_1*((double)numWords / numSentences) + C_2*((double)numSyllables / numWords);
	}	
	
	/**
	 * Sample output for Flesch-Kincaid Grade Level
	 * 
	 * @param args command-line arguments (not used)
	 */
	public void main(String[] args) {		
		String text = "Roses are red. Violets are blue. Sugar is sweet, And so are you!";
		System.out.println("Flesch-Kincaid: " + fleschKincaid(text) + ", Expected: 0.6230769230769244");
	}	
}
