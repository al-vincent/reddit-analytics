/**=============================================================================
 * MSc Project - Reddit LanguageComplexity MapReduce Program (Mapper)
 * ------------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment text and calculates the Flesch-Kincaid
 *				grade level score for each comment. To do this, gets:
 *				- number of sentences in body-text (via opennlp)
 *				- number of words in body-text (via opennlp)
 *				- number of syllables in body-text (estimate, using heuristic)
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class LanguageComplexityMapper extends Mapper<Object, Text, Text, CommentWritable> {
	// instance of a CommentWritable (custom output format)
	private CommentWritable output = new CommentWritable();					
	
	// path to the training models that are used
	//private final String modelPath = System.getProperty("user.dir") + "/lib/";
	private final String modelPath = "";//"~/lib/";
	// strings to be used as 'vowels' (i.e. incl 'y')
	private final HashSet<String> vowels = new HashSet<String>(Arrays.asList("a", "e", "i", "o", "u", "y"));
	
	// Flesch-Kincaid constants (experimentally derived)
	private final double C_0 = -15.59;
	private final double C_1 = 0.39;
	private final double C_2 = 11.8;
	
	// initialise the models that will be used
	private SentenceModel sentenceModel = null;
	private TokenizerModel tokenizerModel = null;
	
	// Pattern for recognising a URL, based off RFC 3986
	private static final Pattern urlPattern = Pattern.compile("(?:^|[\\W])((ht|f)tp(s?):\\/\\/|www\\.)"
                + "(([\\w\\-]+\\.){1,}?([\\w\\-.~]+\\/?)*"
                + "[\\p{Alnum}.,%_=?&#\\-+()\\[\\]\\*$~@!:/{};']*)", 
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

	// The map method
	public void map(Object key, Text value, Context context
			) throws IOException, InterruptedException {		
		
		// Parse the reddit json input, by placing each key:value pair into a HashMap
		String jsonString = value.toString();
		HashMap<String,String> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, String>>() {}.getType());			
		
		// get the name of the subreddit
		Text subreddit = new Text(comment.get("subreddit"));
		
		// Calculate the Flesch-Kincaid grade level for the body text
		String bodyText = preProcess(comment.get("body"));
		
		// set the values for output
		output.setFleschKincaid(fleschKincaid(bodyText));
		output.setCount(1);
		//output.setPostId(comment.get("parent_id"));		
			 
		// Emit <key, value> pair - key = subreddit name, val = 
		context.write(subreddit, output);											   		
	}
	
	public String preProcess(String input)
	{
		String strClean = input;
		
		// remove any urls (not language)
		Matcher matcher = urlPattern.matcher(input);
		strClean = matcher.replaceAll("");
		
		// Convert strClean to lower case to make it case insensitive
		strClean = strClean.toLowerCase();
		
		// Change words like can't into cant  
		strClean = strClean.replaceAll("'", ""); 
						
		// Trim the leading and trailing white spaces
		strClean = strClean.trim();
		
		return strClean;
	}
	
	/**
	 * Heuristic method to approximate the number of syllables in a word (in English). 
	 * Calculated by counting the number of vowels (incl 'y') in a word, excluding cases where:
	 * 	- vowels that have vowels directly before them;
	 *  - the letter 'e' appears by itself at the end of a word.
	 *  
	 * @param word String, word that we want to estimate the number of syllables for.
	 * @return int representing the approximate number of syllables in 'word' 
	 */
	public int countSyllablesInWord(String word){
		// Vowels are all lower case, so set the word to be lower case too
		word = word.toLowerCase();
		// initialise syllable counter
		int sylCount = 0;
		// word length is used a few times, so store in a variable
		int wordLength = word.length();
		
		// look through each character in the word
		for(int i = 0; i < wordLength; i++){
			// if the character is a vowel, then...
			if(vowels.contains(word.substring(i, i+1))){
				//.. if it's the first letter, increment the syllable counter
				if(i == 0){
					sylCount++;
				// if it's not the first or last letter, and the previous letter
				// is not a vowel, then increment the syllable counter
				} else if(i > 0 && i < wordLength-1 && !vowels.contains(word.substring(i-1, i))){
					sylCount++;
				// finally, if it's the last letter, *not* an 'e' and the previous 
				// letter isn't a vowel, then increment the syllable counter
				} else if(i == wordLength-1 && word.charAt(i) != 'e' && !vowels.contains(word.substring(i-1, i))){
					sylCount++;
				}
			}
		}
		
		// A word can never have less than one syllable; if it does (e.g. an abbreviation),  
		// set the count to 1
		if(sylCount < 1) sylCount = 1;
		
		return sylCount;
	}
	
	/**
	 * Count the total number of syllables in a collection of words.
	 * 
	 * @param text an ArrayList<String>, where each entry is a single word 
	 * that we want to count the number of syllables for. 
	 * @return int representing the (approximate) total number of syllables 
	 * in all words in 'text'
	 */
	public int countSyllablesInText(ArrayList<String> text){
		
		// initialise the counter to zero
		int syllableCount = 0;
		// iterate through each word in the ArrayList
		for(String word : text){
			// update syllableCount with number of syllables in the word
			syllableCount += countSyllablesInWord(word);
		}
		return syllableCount;
	}
	
	/**
	 * Count the number of sentences in a piece of text. Uses OpenNLP's SentenceModel
	 * to provide a high level of accuracy on sentence estimation.
	 *   
	 * @param text the text whose sentences we wish to extract
	 * @return an integer representing the number of sentences in the text
	 */
	public int countSentences(String text) {
		
		// sentenceModel should be remembered *between* mapper iterations, so we only
		// need to train it once
		if(sentenceModel == null){						
			try (InputStream modelIn = new FileInputStream(modelPath + "en-sent.zip")) {
				  sentenceModel = new SentenceModel(modelIn);
			} catch (IOException e) {
				e.printStackTrace();
			} 
		}
		
		// Create SentenceDetector object from the model above
		SentenceDetectorME sentenceDetector = new SentenceDetectorME(sentenceModel);

		// Detect the sentences in 'text'. Store each sentence as an element in an 
		// array of strings
		String sentences[] = sentenceDetector.sentDetect(text);
		
		// The number of elements in this array is the number of sentences 
		return sentences.length;				
	}
	
	/**
	 * Tokenise a passage of text and extract likely words from that text (removing
	 * punctuation, white space etc).
	 * 
	 * @param text a String to be tokenized
	 * @return words an ArrayList<String> of likely words
	 * 
	 * NOTES:
	 * 	- The method used to identify 'words' is not currently very accurate; just
	 * 	  looks for tokens that begin with a letter.
	 */
	public ArrayList<String> wordsInText(String text){
		
		// variable to hold the word-count
		ArrayList<String> words = new ArrayList<String>();
		
		// set up the TokenizerModel
		if(tokenizerModel == null) {
			try (InputStream modelIn = new FileInputStream(modelPath + "en-token.zip")) {
				  tokenizerModel = new TokenizerModel(modelIn);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		// Create a Tokenizer object 
		Tokenizer tokenizer = new TokenizerME(tokenizerModel);
		
		// Get the tokens from the input text and store in a String array
		String tokens[] = tokenizer.tokenize(text);
				
		// Look through each token - if the first char is a letter, then 
		// treat the token as a word and add to the arraylist
		for(String token : tokens){			
			if(Character.isLetter(token.charAt(0))) {				
				//if(token.length() > 3 && !token.substring(0, 4).equalsIgnoreCase("http")){
				if(token.length() > 3){
				//System.out.println("word: " + token);
					words.add(token);
				} else if (token.length() <= 3) {
					words.add(token);
				}
			}
		}		
		return words;
	}
	
	/**
	 * Calculate the Flesch-Kincaid grade score for a piece of text. Briefly; Flesch-Kincaid 
	 * provides an approximation of the complexity of a piece of text. The higher the number,
	 * the more complex the language used in the text. For more details, see 
	 * https://en.wikipedia.org/wiki/Flesch%E2%80%93Kincaid_readability_tests
	 *    
	 * Formula is:
	 * 	Grade = C_0 + C_1 * (num_words / num_sentences) + C_2 * (num_syllables / num_words),
	 * where C_0, C_1, C_2 are constants.
	 * 
	 * @param text the text that we want to calculate Flesch-Kincaid for.
	 * @return a double representing the Flesch-Kincaid Grade Level 
	 */
	public double fleschKincaid(String text){
		int numSentences = countSentences(text);
		ArrayList<String> words = wordsInText(text);
		int numWords = words.size();
		int numSyllables = countSyllablesInText(words);
				
		double fc = 0.0;
		if(numWords != 0 && numSentences != 0 && numSyllables != 0) {
			fc = C_0 + C_1*((double)numWords / numSentences) + C_2*((double)numSyllables / numWords); 
		}
		
		return fc;
	}	
}