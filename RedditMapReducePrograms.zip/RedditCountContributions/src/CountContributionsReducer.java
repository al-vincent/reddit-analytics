/**=============================================================================
 * MSc Project - Reddit CountContributions MapReduce Program (Reducer)
 * -------------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment *OR* post data and extracts the number of 
 * 				contributions per subreddit.
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CountContributionsReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

	// instance variables 
	private IntWritable result = new IntWritable();	
	
	// The reducer method
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		// iterate through values, and sum the result		
		int sum = 0;
		for (IntWritable val : values) {
			// accumulate the result in the 'sum' variable
			sum += val.get(); 
		}
		
		// Set and output the result
		this.result.set(sum);
		context.write(key, this.result);		
	}
}