/**=============================================================================
 * MSc Project - Reddit CountContributions MapReduce Program (Mapper)
 * -----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit comment *OR* post data and extracts the number of 
 * 				contributions per subreddit.
 * 				Emits <subreddit, 1>
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CountContributionsMapper extends Mapper<Object, Text, Text, IntWritable> {
	// instance variables
	private Text subreddit = new Text();						
	private final IntWritable one = new IntWritable(1); 

	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

		// The FileInputFormat will supply input elements to the mapper line-by-line using the line number as a key.
		
		// try to parse json
		String jsonString = value.toString();
		HashMap<String,Object> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, Object>>() {}.getType());
		
		// get subreddit name, and emit <subreddit, 1> if subreddit is not null
		try {
			subreddit.set(comment.get("subreddit").toString());
			context.write(this.subreddit, this.one);
		} catch (NullPointerException e) {
			// ignore any subreddits with a null name (these are invalid)
		}																	   	
	}
}
