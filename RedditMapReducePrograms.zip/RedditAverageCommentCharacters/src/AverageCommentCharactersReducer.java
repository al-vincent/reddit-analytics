/**=============================================================================
 * MSc Project - Reddit AverageCommentCharacters MapReduce Program (Reducer)
 * ------------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes the <subreddit, commentAve> pairs from the mapper and 
 * 				calculates the overall average number of characters per comment
 * 				in each subreddit.
 * 
 * 				Emits: <subreddit_name, num_users> pairs
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class AverageCommentCharactersReducer extends Reducer<Text, CountAverageWritable, Text, CountAverageWritable> {

	// Instance variables (stored state between iterations of the reduce task)
	private CountAverageWritable result = new CountAverageWritable();

	// The reducer method
	public void reduce(Text key, Iterable<CountAverageWritable> values, Context context) throws IOException,
	InterruptedException {

		// variables to hold totals
		double sum = 0.;
		double count = 0.;
		
		for (CountAverageWritable val : values) {
			// accumulate the result in the 'sum' variable
			sum += val.getCount() * val.getAverage();
			// track the number of comments seen in the 'count' variable 
			count += val.getCount();
		}
		
		// Set and enit the results
		result.setCount(count);
		result.setAverage(sum / count);
		
		context.write(key, result);
	}
}