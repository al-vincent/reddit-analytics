/**=============================================================================
 * MSc Project - Reddit AverageCommentCharacters MapReduce Program (Mapper)
 * -----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Reads Reddit comment data line-by-line. Extracts the name of
 * 				the subreddit and the number of characters in the body-text.
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AverageCommentCharactersMapper extends Mapper<Object, Text, Text, CountAverageWritable> {
	
	// instance variables
	private Text subreddit = new Text();					
	private CountAverageWritable commentAve = new CountAverageWritable();

	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {		
	
		// (try to) parse json
		String jsonString = value.toString();
		// create a HashMap of [field : value] pairs from the json
		HashMap<String,String> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, String>>() {}.getType());			
		
		// set the name of the subreddit (used as the key)
		subreddit.set(comment.get("subreddit"));
		// set Average to the number of body-text characters, and Count to 1 
		commentAve.setAverage(comment.get("body").length());
		commentAve.setCount(1.0);
		
		// Emit (subreddit, userId) 
		context.write(subreddit, commentAve);
	}
}
