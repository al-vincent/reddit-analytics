import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Writable;


public class CountAverageWritable implements Writable {
	
	private DoubleWritable  count = new DoubleWritable ();
	private DoubleWritable average = new DoubleWritable();

	@Override
	public void readFields(DataInput in) throws IOException {
		this.average.readFields(in);
		this.count.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		this.average.write(out);
		this.count.write(out);
	}

	public void setAverage(double ave) {
		// Set the value of the sum field
		this.average.set(ave);
	}
	
	public void setCount(double ct) {
		// Set the value of the count field
		this.count.set(ct);
	}
	
	public double getAverage() {
		// Replace 0 with the value of extracted from average field
		return this.average.get();
	}
	
	public double getCount() {
		// Replace 0 with the value extracted from the count field
		return this.count.get();
	}
	
	public String toString() {
		return this.count + "\t" + this.average ;
	}
}
