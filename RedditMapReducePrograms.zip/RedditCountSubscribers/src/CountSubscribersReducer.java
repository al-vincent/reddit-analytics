/**=============================================================================
 * MSc Project - Reddit CountSubscribers MapReduce Program (Reducer)
 * -----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Gets the most recent subscriber info for each subreddit in the
 * 				data set. 
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/subreddits/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CountSubscribersReducer extends Reducer<Text, SubredditWritable, Text, SubredditWritable> {

	// Instance variable
	private SubredditWritable result = new SubredditWritable();
	
	// The reducer method
	public void reduce(Text key, Iterable<SubredditWritable> values, Context context) throws IOException, InterruptedException {

		// intialise the timestamp to 0;
		result.setTimestamp(0);
		// Iterate through each value, and increment selfPostCount and linkPostCount accordingly 
		for (SubredditWritable val : values) {
			// if the timestamp is later (i.e. more recent) than the current timestamp, then overwrite current
			// timestamp and subscriberCount
			if(val.getTimestamp() > result.getTimestamp()){
				result.setTimestamp(val.getTimestamp());
				result.setSubscriberCount(val.getSubscriberCount());
			}
		}
		
		// Output the result
		context.write(key, result);
	}
}