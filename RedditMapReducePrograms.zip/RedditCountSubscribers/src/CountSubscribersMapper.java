/**=============================================================================
 * MSc Project - Reddit CountSubscribers MapReduce Program (Mapper)
 * ----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes Reddit subreddit data from JSON file, line-by-line. 
 * 				
 * 				Extracts the name of the subreddit, the number of subscribers
 * 				and the timestamp of the info, then outputs this information.  
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/subreddits/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class CountSubscribersMapper extends Mapper<Object, Text, Text, SubredditWritable> {

	// instance variables	
	private Text name = new Text();
	private SubredditWritable subreddit = new SubredditWritable();

	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {		

		// The FileInputFormat will supply input elements to the mapper line-by-line using the line number as a key.
		
		// try to parse json
		String subredditJson = value.toString();
		// convert source json to HashMap for easy info retrieval
		HashMap<String, Object> subredInfo = new Gson().fromJson(subredditJson, new TypeToken<HashMap<String, Object>>() {}.getType());
		
		// set instance variables from json input
		// name of subreddit; guaranteed to exist..? Unsure. 
		String displayName = "<empty_name>"; 
		try {
			displayName = subredInfo.get("display_name").toString();
		} catch (NullPointerException e) {
			// continue
		}
		name.set(displayName);
		
		// number of subscribers; *NOT* guaranteed to exist!!
		int subscriberCount = -1;	// if subscriber count is not null, this will be overwritten (incl if it's zero)	
		try {
			subscriberCount = (int)Double.parseDouble(subredInfo.get("subscribers").toString());
		} catch (NullPointerException e) {
			// continue
		}
		subreddit.setSubscriberCount(subscriberCount);
		
		// timestamp; guaranteed to exist..? Unsure.
		int timestamp = -1;
		try {
			timestamp = (int)Double.parseDouble(subredInfo.get("created_utc").toString());
		} catch (NullPointerException e) {
			// continue
		}
		subreddit.setTimestamp(timestamp);		

		// write output
		context.write(name, subreddit);										   		
	}
}
