import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;

public class SubredditWritable implements Writable{	
	private IntWritable subscriberCount = new IntWritable();
	private IntWritable timestamp = new IntWritable();

	@Override
	public void readFields(DataInput in) throws IOException {		
		this.subscriberCount.readFields(in);
		this.timestamp.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		this.subscriberCount.write(out);
		this.timestamp.write(out);		
	}
	
	public void setSubscriberCount(int i) {
		// Set the value of the 'subscriberCount' field
		this.subscriberCount.set(i);
	}
	
	public void setTimestamp(int i) {
		// Set the value of the 'timestamp' field
		this.timestamp.set(i);
	}
	
	public int getSubscriberCount() {
		// Return the current value of 'subcriberCount' as an int
		return this.subscriberCount.get();
	}
	
	public int getTimestamp() {
		// Return the current value of 'timestamp' as an int
		return this.timestamp.get();
	}
		
	public String toString() {
		return this.subscriberCount + "\t" + this.timestamp;
	}
}

