/**=============================================================================
 * MSc Project - Reddit CountContributors MapReduce Program (Mapper)
 * -----------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Reads Reddit comment data line-by-line and extracts the IDs of 
 * 				commentors and posters.
 * 
 * 				Emits: <subreddit_name, user_id> pairs
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
import java.util.HashMap;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CountContributorsMapper extends Mapper<Object, Text, Text, Text> {
	
	// Self-defined null string, to indicate that the JSON input field is null.
	// Won't be needed for any 'comments' data, but will be for 'submissions' data
	public static final String nullString = "__NULL__";
	
	// instance variables
	private Text subreddit = new Text();					
	private Text posterInfo = new Text();

	// The map method
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {		
	
		// (try to) parse JSON
		String jsonString = value.toString();
		// Create a HashMap of [field : value] pairs from the json.
		// NOTE the HashMap is <String,Object>; this deals with annoying embedded media objects in the JSON
		HashMap<String,Object> comment = new Gson().fromJson(jsonString, new TypeToken<HashMap<String, Object>>() {}.getType());			
		
		// Set the name of the subreddit. If null, set to "NULL"
		try {
			subreddit.set(comment.get("subreddit").toString());
		} catch ( NullPointerException e) {
			subreddit.set(nullString);
		}
		
		// Set the name of the poster. If null (indicating that the post is an advert), set to nullString
		try{
			posterInfo.set(comment.get("author").toString());
		} catch ( NullPointerException e ) {
			posterInfo.set(nullString);
		}
				
		// Emit (subreddit, userId) 
		context.write(subreddit, posterInfo);											   		
	}
}
