/**=============================================================================
 * MSc Project - Reddit CountContributors MapReduce Program (Reducer)
 * ------------------------------------------------------------------
 * 
 * @author 		A. Vincent
 * 
 * Description: Takes the <subreddit, userID> pairs from the mapper, builds 
 * 				a HashSet of userIds, and returns its length.
 * 
 * 				Emits: <subreddit_name, num_users> pairs
 * 
 * Input data:  JSON files, from http://files.pushshift.io/reddit/comments/
 * 
 * JSON schema:	see https://github.com/reddit/reddit/wiki/JSON
 * =============================================================================*/

import java.io.IOException;
//import java.util.HashMap;
import java.util.HashSet;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CountContributorsReducer extends Reducer<Text, Text, Text, IntWritable> {

	// Instance variables (stored state between iterations of the reduce task)
	private IntWritable userCount = new IntWritable();
	private HashSet<String> posterIds = new HashSet<String>();

	// The reducer method 
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		// clear the HashSet (all users for a specific subreddit key are guaranteed to be 
		// together in 'values') 
		posterIds.clear();
		
		// iterate through each userID in the 'values' Iterable; add the user ID to the HashSet 
		// (if it isn't already there, and isn't null)	
		for(Text val : values){			
			if(!val.toString().equals(CountContributorsMapper.nullString)){
				posterIds.add(val.toString());
			}
		}
		
		// get the number of unique posters (size of the HashSet)
		userCount.set(posterIds.size());
		
		// emit the <subbredditName, userCount> pair
		context.write(key, userCount);
	}
}